package com.company;

public class Barbarian {
    static int pvOfBarbarian;//value of barbarian's HP

        public Barbarian(){

            pvOfBarbarian = 20;// barbarian's HP
            Axe BarbarianWeapon = new Axe(); //barbarian's weapon
        }
}
