package com.company;

public class Weapons {
    public Weapons() {
    }
}

