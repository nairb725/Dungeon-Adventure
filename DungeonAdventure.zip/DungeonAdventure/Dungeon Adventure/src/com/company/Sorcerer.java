package com.company;

public class Sorcerer {
    static int pvOfSorcerer;//value of sorcerer's HP

        public Sorcerer() {

            pvOfSorcerer = 20;// sorcerer's HP
            StrikeOfLightning SorcererWeapon = new StrikeOfLightning();//sorcerer's weapon
        }
    }
