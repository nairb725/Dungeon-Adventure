package com.company;

public class Room {
    public Room(String ennemy) {
        new Ennemy(ennemy);
    } //Spawn a random ennemy
}
